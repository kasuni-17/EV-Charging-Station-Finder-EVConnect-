/* EvConnect – script.js */

// ── NAV SCROLL EFFECT ─────────────────────────────────────
const navbar = document.getElementById('navbar');
if (navbar) {
  window.addEventListener('scroll', () => {
    navbar.classList.toggle('scrolled', window.scrollY > 20);
  });
}

// ── HAMBURGER ─────────────────────────────────────────────
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobileMenu');
if (hamburger && mobileMenu) {
  hamburger.addEventListener('click', () => {
    mobileMenu.classList.toggle('open');
  });
}

// ── SET TODAY AS MIN DATE FOR BOOKING ─────────────────────
const bookDate = document.getElementById('bookDate');
if (bookDate) {
  const today = new Date().toISOString().split('T')[0];
  bookDate.min = today;
  bookDate.value = today;
}

// ── STATIONS DATA ─────────────────────────────────────────
const stationsData = [
  {
    id: 1, name: 'City Center Hub', address: 'Colombo 03',
    dist: 0.8, connectors: ['CCS2', 'Type2', 'CHAdeMO'],
    maxKw: 150, price: 45, rating: 4.8, free: 3, total: 5,
    hours: '24/7', amenities: ['Parking', 'WiFi', 'Café'],
    status: 'available'
  },
  {
    id: 2, name: 'Kandy Road Express', address: 'Kelaniya',
    dist: 5.2, connectors: ['CCS2', 'Type2'],
    maxKw: 100, price: 40, rating: 4.6, free: 5, total: 6,
    hours: '6am–10pm', amenities: ['Parking', 'Restroom'],
    status: 'available'
  },
  {
    id: 3, name: 'Marina Beach Charge', address: 'Galle Face',
    dist: 1.4, connectors: ['Type2', 'CCS2'],
    maxKw: 50, price: 42, rating: 4.5, free: 1, total: 4,
    hours: '7am–9pm', amenities: ['Parking', 'Beach access'],
    status: 'busy'
  },
  {
    id: 4, name: 'Nugegoda Square', address: 'Nugegoda',
    dist: 3.1, connectors: ['CCS2', 'Type2', 'CHAdeMO'],
    maxKw: 150, price: 44, rating: 4.7, free: 4, total: 6,
    hours: '24/7', amenities: ['Parking', 'Shopping', 'WiFi'],
    status: 'available'
  },
  {
    id: 5, name: 'Dehiwala Point', address: 'Dehiwala',
    dist: 6.5, connectors: ['Type2'],
    maxKw: 22, price: 38, rating: 4.2, free: 0, total: 2,
    hours: '8am–8pm', amenities: ['Parking'],
    status: 'full'
  },
  {
    id: 6, name: 'Rajagiriya Hub', address: 'Rajagiriya',
    dist: 4.8, connectors: ['CCS2', 'Type2'],
    maxKw: 100, price: 43, rating: 4.6, free: 2, total: 4,
    hours: '24/7', amenities: ['Parking', 'WiFi'],
    status: 'available'
  },
  {
    id: 7, name: 'Maharagama Charge', address: 'Maharagama',
    dist: 7.2, connectors: ['CCS2', 'Type2', 'CHAdeMO'],
    maxKw: 150, price: 41, rating: 4.5, free: 6, total: 8,
    hours: '24/7', amenities: ['Parking', 'Restroom', 'Café'],
    status: 'available'
  }
];

let filteredStations = [...stationsData];
let currentView = 'list';

function renderStations(data) {
  const container = document.getElementById('stationsContainer');
  const countEl = document.getElementById('stationCount');
  if (!container) return;

  countEl && (countEl.textContent = `${data.length} station${data.length !== 1 ? 's' : ''} found`);

  if (data.length === 0) {
    container.innerHTML = `<div style="text-align:center;padding:40px;color:var(--muted);">
      <div style="font-size:2rem;margin-bottom:12px;">🔍</div>
      <div style="font-weight:600;margin-bottom:6px;">No stations found</div>
      <div style="font-size:13px;">Try adjusting your filters</div>
    </div>`;
    return;
  }

  container.innerHTML = data.map(s => {
    const statusColor = s.status === 'available' ? 'available' : s.status === 'busy' ? 'busy' : 'full';
    const statusLabel = s.free > 0 ? `${s.free} Available` : 'Full';
    const badgeClass = s.free > 1 ? 'available' : s.free === 1 ? 'busy' : 'full';
    return `
    <div class="station-list-item" onclick="openStationModal(${s.id})">
      <div class="sli-top">
        <div>
          <div class="sli-name">${s.name}</div>
          <div class="sli-addr">📍 ${s.address} · ${s.dist} km</div>
        </div>
        <div class="sc-badge ${badgeClass}">${statusLabel}</div>
      </div>
      <div class="sli-meta">
        ${s.connectors.map(c => `<span class="conn">${c}</span>`).join('')}
        <span>⚡ ${s.maxKw} kW</span>
        <span>💰 LKR ${s.price}/kWh</span>
        <span>⭐ ${s.rating}</span>
      </div>
      <div class="sli-actions">
        <span class="btn-detail" onclick="event.stopPropagation();openStationModal(${s.id})">Details</span>
        <a href="booking.html" class="btn-book" onclick="event.stopPropagation()">Book Now</a>
      </div>
    </div>
    `;
  }).join('');
}

function filterStations() {
  const search = document.getElementById('searchInput')?.value.toLowerCase() || '';
  const conn = document.getElementById('connectorFilter')?.value || '';
  const status = document.getElementById('statusFilter')?.value || '';
  const sort = document.getElementById('sortFilter')?.value || 'distance';

  let result = stationsData.filter(s => {
    const matchSearch = !search || s.name.toLowerCase().includes(search) || s.address.toLowerCase().includes(search);
    const matchConn = !conn || s.connectors.includes(conn);
    const matchStatus = !status || (status === 'available' && s.free > 0) || (status === 'busy' && s.free === 0);
    return matchSearch && matchConn && matchStatus;
  });

  if (sort === 'distance') result.sort((a, b) => a.dist - b.dist);
  if (sort === 'rating') result.sort((a, b) => b.rating - a.rating);
  if (sort === 'price') result.sort((a, b) => a.price - b.price);

  filteredStations = result;
  renderStations(result);
}

function setView(view) {
  currentView = view;
  const container = document.getElementById('stationsContainer');
  const listBtn = document.getElementById('listBtn');
  const gridBtn = document.getElementById('gridBtn');
  if (!container) return;

  if (view === 'grid') {
    container.classList.add('grid-view');
    gridBtn?.classList.add('active');
    listBtn?.classList.remove('active');
  } else {
    container.classList.remove('grid-view');
    listBtn?.classList.add('active');
    gridBtn?.classList.remove('active');
  }
}

function openStationModal(id) {
  const s = stationsData.find(x => x.id === id);
  if (!s) return;
  const modal = document.getElementById('stationModal');
  const content = document.getElementById('modalContent');
  if (!modal || !content) return;

  const portData = {
    'CCS2': { kw: '150kW DC', free: s.free > 0 },
    'Type2': { kw: '22kW AC', free: s.free > 1 },
    'CHAdeMO': { kw: '50kW DC', free: s.free > 2 }
  };

  content.innerHTML = `
    <div class="modal-station-name">${s.name}</div>
    <div class="modal-addr">📍 ${s.address} · ${s.dist} km away</div>
    <div class="modal-ports">
      ${s.connectors.map(c => {
        const p = portData[c] || { kw: 'AC', free: true };
        return `<div class="modal-port ${p.free ? 'free' : 'busy'}">
          <strong>${c}</strong>
          <small>${p.kw} · ${p.free ? '✅ Free' : '🔴 In Use'}</small>
        </div>`;
      }).join('')}
    </div>
    <div class="modal-meta">
      <div class="modal-meta-item"><label>Max Power</label><span>⚡ ${s.maxKw} kW</span></div>
      <div class="modal-meta-item"><label>Price</label><span>💰 LKR ${s.price}/kWh</span></div>
      <div class="modal-meta-item"><label>Rating</label><span>⭐ ${s.rating} / 5</span></div>
      <div class="modal-meta-item"><label>Hours</label><span>🕐 ${s.hours}</span></div>
    </div>
    <div style="margin-bottom:16px;">
      <label style="font-size:12px;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:.05em;">Amenities</label>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px;">
        ${s.amenities.map(a => `<span style="background:var(--bg);border:1px solid var(--border);padding:4px 10px;border-radius:6px;font-size:12px;">${a}</span>`).join('')}
      </div>
    </div>
    <div style="display:flex;gap:12px;">
      <a href="booking.html" class="btn-primary" style="flex:1;justify-content:center;">Book a Slot</a>
      <button onclick="closeModal()" class="btn-ghost" style="flex:1;justify-content:center;">Close</button>
    </div>
  `;

  modal.classList.add('open');
}

function closeModal() {
  document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('open'));
}

// Close modal on overlay click
document.querySelectorAll('.modal-overlay').forEach(overlay => {
  overlay.addEventListener('click', e => {
    if (e.target === overlay) closeModal();
  });
});

// ── BOOKING STEPPER ───────────────────────────────────────
let bookingData = {
  station: 'City Center Hub',
  date: '',
  time: '10:00',
  duration: '60',
  connector: 'CCS2',
  name: '', email: '', phone: '', vehicle: '',
  payment: 'card'
};

function nextStep(step) {
  if (step === 3) {
    const name = document.getElementById('fullName')?.value.trim();
    const email = document.getElementById('email')?.value.trim();
    // gather details
    if (document.getElementById('fullName')) bookingData.name = name;
    if (document.getElementById('email')) bookingData.email = email;
    if (document.getElementById('phone')) bookingData.phone = document.getElementById('phone').value.trim();
    if (document.getElementById('vehicle')) bookingData.vehicle = document.getElementById('vehicle').value.trim();
    if (document.getElementById('bookDate')) bookingData.date = document.getElementById('bookDate').value;
    if (document.getElementById('duration')) bookingData.duration = document.getElementById('duration').value;
  }

  if (step === 4) {
    if (!document.getElementById('fullName')?.value.trim()) {
      alert('Please enter your full name.');
      return;
    }
    if (!document.getElementById('email')?.value.trim()) {
      alert('Please enter your email address.');
      return;
    }
    bookingData.name = document.getElementById('fullName').value.trim();
    bookingData.email = document.getElementById('email').value.trim();
    buildSummary();
  }

  goToStep(step);
}

function prevStep(step) {
  goToStep(step);
}

function goToStep(step) {
  document.querySelectorAll('.form-step').forEach(s => s.classList.remove('active'));
  document.getElementById(`step${step}`)?.classList.add('active');

  document.querySelectorAll('.step-dot').forEach((dot, i) => {
    dot.classList.remove('active', 'done');
    if (i + 1 < step) dot.classList.add('done'), dot.querySelector('span').textContent = '✓';
    else if (i + 1 === step) dot.classList.add('active');
    else dot.querySelector('span').textContent = i + 1;
  });
  document.querySelectorAll('.step-line').forEach((line, i) => {
    line.classList.toggle('done', i + 1 < step);
  });
}

function buildSummary() {
  const summary = document.getElementById('bookingSummary');
  if (!summary) return;

  const d = bookingData;
  const dateStr = d.date ? new Date(d.date + 'T00:00').toLocaleDateString('en-LK', { weekday: 'short', day: 'numeric', month: 'short' }) : 'Today';
  const durLabel = { '30': '30 mins', '60': '1 hour', '90': '1.5 hours', '120': '2 hours' }[d.duration] || '1 hour';
  const estKwh = Math.round((parseInt(d.duration) / 60) * 15);
  const estCost = estKwh * 45;

  summary.innerHTML = `
    <div class="summary-row"><label>Station</label><span>${d.station}</span></div>
    <div class="summary-row"><label>Date</label><span>${dateStr}</span></div>
    <div class="summary-row"><label>Time</label><span>${d.time}</span></div>
    <div class="summary-row"><label>Duration</label><span>${durLabel}</span></div>
    <div class="summary-row"><label>Connector</label><span>${d.connector}</span></div>
    <div class="summary-row"><label>Name</label><span>${d.name || '—'}</span></div>
    <div class="summary-row"><label>Est. Energy</label><span>~${estKwh} kWh</span></div>
    <div class="summary-row" style="margin-top:8px;padding-top:12px;border-top:2px solid var(--border);">
      <label style="font-weight:700;color:var(--dark);">Est. Total</label>
      <span style="color:var(--green-dark);font-size:1.1rem;">LKR ${estCost}</span>
    </div>
  `;

  // Update sidebar
  document.getElementById('sum-date') && (document.getElementById('sum-date').textContent = dateStr);
  document.getElementById('sum-duration') && (document.getElementById('sum-duration').textContent = durLabel);
  document.getElementById('sum-cost') && (document.getElementById('sum-cost').textContent = `LKR ${estCost}`);
}

function selectSlot(btn, time) {
  document.querySelectorAll('.time-slot.selected').forEach(b => b.classList.remove('selected'));
  btn.classList.add('selected');
  bookingData.time = time;
  document.getElementById('sum-time') && (document.getElementById('sum-time').textContent = time);
}

function selectConn(btn, conn) {
  document.querySelectorAll('.conn-btn.selected').forEach(b => b.classList.remove('selected'));
  btn.classList.add('selected');
  bookingData.connector = conn;
  document.getElementById('sum-conn') && (document.getElementById('sum-conn').textContent = conn);
}

// Station picker
document.querySelectorAll('.sp-card').forEach(card => {
  card.addEventListener('click', function () {
    document.querySelectorAll('.sp-card.selected').forEach(c => c.classList.remove('selected'));
    this.classList.add('selected');
    bookingData.station = this.dataset.station;
    const sumStation = document.getElementById('sum-station');
    if (sumStation) sumStation.textContent = bookingData.station;
  });
});

// Payment options
document.querySelectorAll('.pay-opt').forEach(opt => {
  opt.addEventListener('click', function () {
    document.querySelectorAll('.pay-opt.selected').forEach(o => o.classList.remove('selected'));
    this.classList.add('selected');
    bookingData.payment = this.querySelector('input').value;
  });
});

// Duration change → update cost
const durationEl = document.getElementById('duration');
if (durationEl) {
  durationEl.addEventListener('change', () => {
    bookingData.duration = durationEl.value;
    const label = durationEl.options[durationEl.selectedIndex].text;
    document.getElementById('sum-duration') && (document.getElementById('sum-duration').textContent = label);
    const estKwh = Math.round((parseInt(durationEl.value) / 60) * 15);
    const estCost = estKwh * 45;
    document.getElementById('sum-cost') && (document.getElementById('sum-cost').textContent = `LKR ${estCost}`);
  });
}

function confirmBooking() {
  const termsCheck = document.getElementById('termsCheck');
  if (!termsCheck?.checked) {
    alert('Please agree to the Terms of Service to continue.');
    return;
  }

  const d = bookingData;
  const dateStr = d.date ? new Date(d.date + 'T00:00').toLocaleDateString('en-LK', { weekday: 'short', day: 'numeric', month: 'short' }) : 'Today';
  const durLabel = { '30': '30 mins', '60': '1 hour', '90': '1.5 hours', '120': '2 hours' }[d.duration] || '1 hour';
  const estKwh = Math.round((parseInt(d.duration) / 60) * 15);
  const estCost = estKwh * 45;
  const refId = 'EVC-' + Date.now().toString(36).toUpperCase().slice(-6);

  document.getElementById('bookingRef').textContent = refId;
  document.getElementById('successDetails').innerHTML = `
    <span><strong>Station:</strong> <span>${d.station}</span></span>
    <span><strong>Date & Time:</strong> <span>${dateStr}, ${d.time}</span></span>
    <span><strong>Duration:</strong> <span>${durLabel}</span></span>
    <span><strong>Connector:</strong> <span>${d.connector}</span></span>
    <span><strong>Est. Cost:</strong> <span>LKR ${estCost}</span></span>
  `;

  document.getElementById('successModal').classList.add('open');
}

// ── INIT ──────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // Stations page
  if (document.getElementById('stationsContainer')) {
    renderStations(stationsData);

    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
      searchInput.addEventListener('keydown', e => {
        if (e.key === 'Enter') filterStations();
      });
    }
  }

  // Add SVG gradient for ring if on home page
  if (document.querySelector('.ring-svg')) {
    const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
    defs.innerHTML = `
      <linearGradient id="ringGrad" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stop-color="#22c55e"/>
        <stop offset="100%" stop-color="#06b6d4"/>
      </linearGradient>
    `;
    document.querySelector('.ring-svg').prepend(defs);
  }

  // Animate on scroll
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.style.opacity = '1';
        e.target.style.transform = 'translateY(0)';
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('.step-card, .station-card, .value-card, .team-card, .coverage-area').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity .5s ease, transform .5s ease';
    observer.observe(el);
  });
});
